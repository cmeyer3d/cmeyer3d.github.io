<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=iso-8859-1">
		<title>Carol Meyer: Floor Plan &amp; Design Services - Process</title>
		<link href="styles/global.css" rel="stylesheet" type="text/css" media="all">
		<csscriptdict import>
			<script type="text/javascript" src="scripts/global.js"></script>
		</csscriptdict>
		<csactiondict>
			<script type="text/javascript"><!--
var preloadFlag = false;
function preloadImages() {
	if (document.images) {
		pre_home_over = newImage('images/nav/home_over.gif');
		pre_whoweare_over = newImage('images/nav/whoweare_over.gif');
		pre_process_over = newImage('images/nav/process_over.gif');
		pre_pricing_over = newImage('images/nav/pricing_over.gif');
		pre_samples_over = newImage('images/nav/samples_over.gif');
		pre_contactus_over = newImage('images/nav/contactus_over.gif');
		preloadFlag = true;
	}
}

// --></script>
		</csactiondict>
	</head>

	<body onload="preloadImages();" bgcolor="#005c81" leftmargin="0" marginheight="0" marginwidth="0" topmargin="0">
		<table width="800" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td colspan="3" width="800"><img src="images/header.gif" alt="Carol Meyer: Floor Plan &amp; Design Services" width="800" height="118" border="0"></td>
			</tr>
			<tr height="12">
				<td width="540" height="12" background="images/box/top.gif"><img src="images/box/top.gif" alt="" width="540" height="12" border="0"></td>
				<td width="12" height="12" background="images/box/cornertop.gif"><img src="images/box/cornertop.gif" alt="" width="12" height="12" border="0"></td>
				<td rowspan="3" valign="top" width="248" background="images/navback.gif">
				
					<div align="center">
					
<!-- BEGIN MEMBER AREA -->					
						<span class="footer">:: Member Login ::</span><br>
						
						<form>
							<input type="text" name="username" value="Username" size="10"> <input type="text" name="password" value="Password" size="10">
						</form>
<!-- END MEMBER AREA -->					
						
					</div>
						
					<p><a onmouseover="changeImages('home','images/nav/home_over.gif');return true" onmouseout="changeImages('home','images/nav/home.gif');return true" href="index.php"><img id="home" src="images/nav/home.gif" alt="Home" name="home" width="248" height="44" border="0"></a><br>
						<a onmouseover="changeImages('whoweare','images/nav/whoweare_over.gif');return true" onmouseout="changeImages('whoweare','images/nav/whoweare.gif');return true" href="whoweare.php"><img id="whoweare" src="images/nav/whoweare.gif" alt="Who We Are" name="whoweare" width="248" height="44" border="0"></a><br>
						<a onmouseover="changeImages('process','images/nav/process_over.gif');return true" onmouseout="changeImages('process','images/nav/process_over.gif');return true" href="process.php"><img id="process" src="images/nav/process_over.gif" alt="Process" name="process" width="248" height="44" border="0"></a><br>
						<a onmouseover="changeImages('pricing','images/nav/pricing_over.gif');return true" onmouseout="changeImages('pricing','images/nav/pricing.gif');return true" href="pricing.php"><img id="pricing" src="images/nav/pricing.gif" alt="Pricing" name="pricing" width="248" height="44" border="0"></a><br>
						<a onmouseover="changeImages('samples','images/nav/samples_over.gif');return true" onmouseout="changeImages('samples','images/nav/samples.gif');return true" href="samples.php"><img id="samples" src="images/nav/samples.gif" alt="Samples" name="samples" width="248" height="44" border="0"></a><br>
						<a onmouseover="changeImages('contactus','images/nav/contactus_over.gif');return true" onmouseout="changeImages('contactus','images/nav/contactus.gif');return true" href="contactus.php"><img id="contactus" src="images/nav/contactus.gif" alt="Contact Us" name="contactus" width="248" height="44" border="0"></a></p>
					<p><br>
					</p>
				</td>
			</tr>
			<tr>
				<td valign="top" bgcolor="#cfdfe6" width="540">
					<div align="center">
					
<!-- BEGIN CONTENT AREA -->
					
						<table width="530" border="0" cellspacing="0" cellpadding="5">
							<tr valign="top">
								<td width="40%"><img src="images/model1.gif" alt="" width="145" height="158" border="0">
									<div class="boxer">
										<p>Check out some of our sample designs <a href="samples.php">here</a>.</p>
									</div>
								</td>
								<td width="60%">
									<div class="content">
										<span class="heading">:: Process :: </span>
										<p><b>The Appointment:</b> <br>
											Appointments to measure properties are made at the convenience of the realtor and/or homeowner. We understand the time sensitivity and make every effort to accommodate our customers. Typically we can schedule appointments within 1-2 days of the request.</p>
										<p><b>The Measure:</b> <br>
											We will meet at the property to accurately measure and sketch the floor plan, discuss room names, and make any special notes that may be requested by the realtor or homeowner. The measure can take anywhere from 1/2 hour to 3 hours depending on the size of the property.</p>
										<p><b>The Floor Plan:</b> <br>
											Computer generated plans are available within 24-48 hours after the Measure. Floor Plans can be mailed, faxed, or electronically transmitted to an e-mail address in PDF, JPEG formats for client review. Changes or revisions can be made at this point. After careful review and final approval, the floor plan may be linked to the MLS listing.</p>
									</div>
								</td>
							</tr>
						</table>
						
<!-- END CONTENT AREA -->
						
					</div>
				</td>
				<td width="12" background="images/box/right.gif"><img src="images/box/right.gif" alt="" width="12" height="360" border="0"></td>
			</tr>
			<tr height="12">
				<td width="540" height="12" background="images/box/bottom.gif"><img src="images/box/bottom.gif" alt="" width="540" height="12" border="0"></td>
				<td width="12" height="12" background="images/box/cornerbut.gif"><img src="images/box/cornerbut.gif" alt="" width="12" height="12" border="0"></td>
			</tr>
			<tr>
				<td colspan="2" align="center" valign="top" width="552">
				
										<br>
					<table width="500" border="0" cellspacing="0" cellpadding="0">
						<tr>
							<td align="center" valign="top">
								<div class="footer">
									<p>:: <a href="index.php">Home</a> :: <a href="whoweare.php">Who We Are</a> :: <a href="process.php">Process</a> :: <a href="pricing.php">Pricing</a> :: <a href="samples.php">Samples</a> :: <a href="contactus.php">Contact Us</a> ::</p>
								</div>
							</td>
							<td align="center" valign="middle" width="35"><img src="images/logosm.gif" alt="" width="25" height="25" border="0"></td>
							<td align="left" valign="top">
								<div class="footer">
									Copyright &copy; 2005 Carol Meyer<br>
										All rights reserved<br>
										[ <a href="sitecredits.php">site credits</a> ]</div>
							</td>
						</tr>
					</table>				
				</td>
				<td width="248"></td>
			</tr>
		</table>
		<p></p>
	</body>

</html>