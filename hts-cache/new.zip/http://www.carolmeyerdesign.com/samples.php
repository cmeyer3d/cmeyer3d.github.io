<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=iso-8859-1">
		<title>Carol Meyer: Floor Plan &amp; Design Services - Samples</title>
		<link href="styles/global.css" rel="stylesheet" type="text/css" media="all">
		<csscriptdict import>
			<script type="text/javascript" src="scripts/global.js"></script>
		</csscriptdict>
		<csactiondict>
			<script type="text/javascript"><!--
var preloadFlag = false;
function preloadImages() {
	if (document.images) {
		pre_home_over = newImage('images/nav/home_over.gif');
		pre_whoweare_over = newImage('images/nav/whoweare_over.gif');
		pre_process_over = newImage('images/nav/process_over.gif');
		pre_pricing_over = newImage('images/nav/pricing_over.gif');
		pre_samples_over = newImage('images/nav/samples_over.gif');
		pre_contactus_over = newImage('images/nav/contactus_over.gif');
		preloadFlag = true;
	}
}
CSAct[/*CMP*/ 'BF5F85372'] = new Array(CSOpenWindow,/*URL*/ 'images/samples/harvard.pdf','sample',800,600,true,true,false,false,false,false,true);
CSAct[/*CMP*/ 'BF5F854E3'] = new Array(CSOpenWindow,/*URL*/ 'images/samples/laurel.pdf','sample',800,600,true,true,false,false,false,false,true);
CSAct[/*CMP*/ 'BF5F856B4'] = new Array(CSOpenWindow,/*URL*/ 'images/samples/miller.pdf','sample',800,600,true,true,false,false,false,false,true);
CSAct[/*CMP*/ 'BF5F85825'] = new Array(CSOpenWindow,/*URL*/ 'images/samples/newbrook.pdf','sample',800,600,true,true,false,false,false,false,true);
CSAct[/*CMP*/ 'BF6B34E01'] = new Array(CSOpenWindow,/*URL*/ 'images/samples/chestnut.pdf','sample',800,600,true,true,false,false,false,false,true);
CSAct[/*CMP*/ 'BF6B34E23'] = new Array(CSOpenWindow,/*URL*/ 'images/samples/commonwealth.pdf','sample',800,600,true,true,false,false,false,false,true);

// --></script>
		</csactiondict>
		<csactions>
			<csaction name="BF5F85372" class="Open Window" type="onevent" val0="images/samples/harvard.pdf" val1="sample" val2="800" val3="600" val4="true" val5="true" val6="false" val7="false" val8="false" val9="false" val10="true" urlparams="1"></csaction>
			<csaction name="BF5F854E3" class="Open Window" type="onevent" val0="images/samples/laurel.pdf" val1="sample" val2="800" val3="600" val4="true" val5="true" val6="false" val7="false" val8="false" val9="false" val10="true" urlparams="1"></csaction>
			<csaction name="BF5F856B4" class="Open Window" type="onevent" val0="images/samples/miller.pdf" val1="sample" val2="800" val3="600" val4="true" val5="true" val6="false" val7="false" val8="false" val9="false" val10="true" urlparams="1"></csaction>
			<csaction name="BF5F85825" class="Open Window" type="onevent" val0="images/samples/newbrook.pdf" val1="sample" val2="800" val3="600" val4="true" val5="true" val6="false" val7="false" val8="false" val9="false" val10="true" urlparams="1"></csaction>
			<csaction name="BF6B34E01" class="Open Window" type="onevent" val0="images/samples/chestnut.pdf" val1="sample" val2="800" val3="600" val4="true" val5="true" val6="false" val7="false" val8="false" val9="false" val10="true" urlparams="1"></csaction>
			<csaction name="BF6B34E23" class="Open Window" type="onevent" val0="images/samples/commonwealth.pdf" val1="sample" val2="800" val3="600" val4="true" val5="true" val6="false" val7="false" val8="false" val9="false" val10="true" urlparams="1"></csaction>
		</csactions>
	</head>

	<body onload="preloadImages();" bgcolor="#005c81" leftmargin="0" marginheight="0" marginwidth="0" topmargin="0">
		<table width="800" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td colspan="3" width="800"><img src="images/header.gif" alt="Carol Meyer: Floor Plan &amp; Design Services" width="800" height="118" border="0"></td>
			</tr>
			<tr height="12">
				<td width="540" height="12" background="images/box/top.gif"><img src="images/box/top.gif" alt="" width="540" height="12" border="0"></td>
				<td width="12" height="12" background="images/box/cornertop.gif"><img src="images/box/cornertop.gif" alt="" width="12" height="12" border="0"></td>
				<td rowspan="3" valign="top" width="248" background="images/navback.gif">
				
					<div align="center">
					
<!-- BEGIN MEMBER AREA -->					
						<span class="footer">:: Member Login ::</span><br>
						
						<form>
							<input type="text" name="username" value="Username" size="10"> <input type="text" name="password" value="Password" size="10">
						</form>
<!-- END MEMBER AREA -->					
						
					</div>
						
					<p><a onmouseover="changeImages('home','images/nav/home_over.gif');return true" onmouseout="changeImages('home','images/nav/home.gif');return true" href="index.php"><img id="home" src="images/nav/home.gif" alt="Home" name="home" width="248" height="44" border="0"></a><br>
						<a onmouseover="changeImages('whoweare','images/nav/whoweare_over.gif');return true" onmouseout="changeImages('whoweare','images/nav/whoweare.gif');return true" href="whoweare.php"><img id="whoweare" src="images/nav/whoweare.gif" alt="Who We Are" name="whoweare" width="248" height="44" border="0"></a><br>
						<a onmouseover="changeImages('process','images/nav/process_over.gif');return true" onmouseout="changeImages('process','images/nav/process.gif');return true" href="process.php"><img id="process" src="images/nav/process.gif" alt="Process" name="process" width="248" height="44" border="0"></a><br>
						<a onmouseover="changeImages('pricing','images/nav/pricing_over.gif');return true" onmouseout="changeImages('pricing','images/nav/pricing.gif');return true" href="pricing.php"><img id="pricing" src="images/nav/pricing.gif" alt="Pricing" name="pricing" width="248" height="44" border="0"></a><br>
						<a onmouseover="changeImages('samples','images/nav/samples_over.gif');return true" onmouseout="changeImages('samples','images/nav/samples_over.gif');return true" href="samples.php"><img id="samples" src="images/nav/samples_over.gif" alt="Samples" name="samples" width="248" height="44" border="0"></a><br>
						<a onmouseover="changeImages('contactus','images/nav/contactus_over.gif');return true" onmouseout="changeImages('contactus','images/nav/contactus.gif');return true" href="contactus.php"><img id="contactus" src="images/nav/contactus.gif" alt="Contact Us" name="contactus" width="248" height="44" border="0"></a></p>
					<p><br>
					</p>
				</td>
			</tr>
			<tr>
				<td valign="top" bgcolor="#cfdfe6" width="540">
					<div align="center">
					
<!-- BEGIN CONTENT AREA -->
						<table width="530" border="0" cellspacing="0" cellpadding="5">
							<tr align="center">
								<td class="boxer" valign="middle" width="100"><a href="http://www.adobe.com/products/acrobat/readstep.html" target="_blank"><img src="images/adobereader.gif" alt="Get the FREE Adobe PDF Reader" width="88" height="31" border="0"></a><br>
									
									[sample viewing requires a PDF reader]
</td>
								<td valign="top" width="60%">
									<div class="content">
										<span class="heading">:: Samples :: </span>
										<div align="center">
											<div class="content">
												<p>The samples shown below are typical.<br>
													Floor plans can be customized to meet the needs of the user.<br>
													[click a sample below for full-size PDF version]</p>
											</div>
										</div>
									</div>
								</td>
							</tr>
						</table>
						<div class="content">
							<p><br>
							</p>
							<table width="400" border="0" cellspacing="0" cellpadding="0">
								<tr align="center">
									<td width="50%"><a onclick="CSAction(new Array(/*CMP*/'BF6B34E01'));return CSClickReturn()" href="#" csclick="BF6B34E01"><img src="images/samples/chestnut.png" alt="Chestnut" width="126" height="384" border="0"></a></td>
									<td width="50%"><a onclick="CSAction(new Array(/*CMP*/'BF6B34E23'));return CSClickReturn()" href="#" csclick="BF6B34E23"><img src="images/samples/commonwealth.png" alt="Common Wealth" width="214" height="384" border="0"></a></td>
								</tr>
							</table>
							<p><br>
								<a onclick="CSAction(new Array(/*CMP*/'BF5F85372'));return CSClickReturn()" href="#" csclick="BF5F85372"><img src="images/samples/harvard.png" alt="Harvard" width="400" height="264" border="0"></a></p>
							<p><br>
								<a onclick="CSAction(new Array(/*CMP*/'BF5F854E3'));return CSClickReturn()" href="#" csclick="BF5F854E3"><img src="images/samples/laurel.png" alt="Laurel" width="400" height="280" border="0"></a></p>
							<p><br>
								<a onclick="CSAction(new Array(/*CMP*/'BF5F856B4'));return CSClickReturn()" href="#" csclick="BF5F856B4"><img src="images/samples/miller.png" alt="Miller" width="400" height="282" border="0"></a></p>
							<p><br>
								<a onclick="CSAction(new Array(/*CMP*/'BF5F85825'));return CSClickReturn()" href="#" csclick="BF5F85825"><img src="images/samples/newbrook.png" alt="Newbrook" width="400" height="336" border="0"></a></p>
						</div>
									
<!-- END CONTENT AREA -->

					</div>
				</td>
				<td width="12" background="images/box/right.gif"><img src="images/box/right.gif" alt="" width="12" height="360" border="0"></td>
			</tr>
			<tr height="12">
				<td width="540" height="12" background="images/box/bottom.gif"><img src="images/box/bottom.gif" alt="" width="540" height="12" border="0"></td>
				<td width="12" height="12" background="images/box/cornerbut.gif"><img src="images/box/cornerbut.gif" alt="" width="12" height="12" border="0"></td>
			</tr>
			<tr>
				<td colspan="2" align="center" valign="top" width="552">
				
										<br>
					<table width="500" border="0" cellspacing="0" cellpadding="0">
						<tr>
							<td align="center" valign="top">
								<div class="footer">
									<p>:: <a href="index.php">Home</a> :: <a href="whoweare.php">Who We Are</a> :: <a href="process.php">Process</a> :: <a href="pricing.php">Pricing</a> :: <a href="samples.php">Samples</a> :: <a href="contactus.php">Contact Us</a> ::</p>
								</div>
							</td>
							<td align="center" valign="middle" width="35"><img src="images/logosm.gif" alt="" width="25" height="25" border="0"></td>
							<td align="left" valign="top">
								<div class="footer">
									Copyright &copy; 2005 Carol Meyer<br>
										All rights reserved<br>
										[ <a href="sitecredits.php">site credits</a> ]</div>
							</td>
						</tr>
					</table>				
				</td>
				<td width="248"></td>
			</tr>
		</table>
		<p></p>
	</body>

</html>