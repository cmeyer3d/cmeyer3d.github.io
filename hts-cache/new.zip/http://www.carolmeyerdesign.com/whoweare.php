<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Carol Meyer: Floor Plan &amp; Design Services - Who We Are</title>
<link href="styles/global.css" rel="stylesheet" type="text/css" media="all">
<csscriptdict import=""></csscriptdict>
<script type="text/javascript" src="scripts/global.js"></script>
<csactiondict></csactiondict>
<script type="text/javascript"><!--
var preloadFlag = false;
function preloadImages() {
	if (document.images) {
		pre_home_over = newImage('images/nav/home_over.gif');
		pre_whoweare_over = newImage('images/nav/whoweare_over.gif');
		pre_process_over = newImage('images/nav/process_over.gif');
		pre_pricing_over = newImage('images/nav/pricing_over.gif');
		pre_samples_over = newImage('images/nav/samples_over.gif');
		pre_contactus_over = newImage('images/nav/contactus_over.gif');
		preloadFlag = true;
	}
}

// --></script>
</head>
<body marginwidth="0" marginheight="0" bgcolor="#005c81" onload="preloadImages();" leftmargin="0" topmargin="0">
<table border="0" cellpadding="0" cellspacing="0" width="800">
<tbody>
<tr>
<td colspan="3" width="800"><img src="images/header.gif" alt="Carol Meyer: Floor Plan &amp; Design Services" border="0" height="118" width="800"></td></tr>
<tr height="12">
<td background="images/box/top.gif" height="12" width="540"><img src="images/box/top.gif" alt="" border="0" height="12" width="540"></td>
<td background="images/box/cornertop.gif" height="12" width="12"><img src="images/box/cornertop.gif" alt="" border="0" height="12" width="12"></td>
<td rowspan="3" background="images/navback.gif" valign="top" width="248">
<div align="center"><!-- BEGIN MEMBER AREA -->					<span class="footer">:: Member Login ::</span><br>
<form><input name="username" value="Username" size="10" type="text"> <input name="password" value="Password" size="10" type="text"></form><!-- END MEMBER AREA -->					</div>
<p><a onmouseover="changeImages('home','images/nav/home_over.gif');return true" onmouseout="changeImages('home','images/nav/home.gif');return true" href="index.php"><img id="home" src="images/nav/home.gif" alt="Home" name="home" border="0" height="44" width="248"></a><br>
<a onmouseover="changeImages('whoweare','images/nav/whoweare_over.gif');return true" onmouseout="changeImages('whoweare','images/nav/whoweare_over.gif');return true" href="whoweare.php"><img id="whoweare" src="images/nav/whoweare_over.gif" alt="Who We Are" name="whoweare" border="0" height="44" width="248"></a><br>
<a onmouseover="changeImages('process','images/nav/process_over.gif');return true" onmouseout="changeImages('process','images/nav/process.gif');return true" href="process.php"><img id="process" src="images/nav/process.gif" alt="Process" name="process" border="0" height="44" width="248"></a><br>
<a onmouseover="changeImages('pricing','images/nav/pricing_over.gif');return true" onmouseout="changeImages('pricing','images/nav/pricing.gif');return true" href="pricing.php"><img id="pricing" src="images/nav/pricing.gif" alt="Pricing" name="pricing" border="0" height="44" width="248"></a><br>
<a onmouseover="changeImages('samples','images/nav/samples_over.gif');return true" onmouseout="changeImages('samples','images/nav/samples.gif');return true" href="samples.php"><img id="samples" src="images/nav/samples.gif" alt="Samples" name="samples" border="0" height="44" width="248"></a><br>
<a onmouseover="changeImages('contactus','images/nav/contactus_over.gif');return true" onmouseout="changeImages('contactus','images/nav/contactus.gif');return true" href="contactus.php"><img id="contactus" src="images/nav/contactus.gif" alt="Contact Us" name="contactus" border="0" height="44" width="248"></a></p>
<p>&nbsp;</p></td></tr>
<tr>
<td bgcolor="#cfdfe6" valign="top" width="540">
<div align="center"><!-- BEGIN CONTENT AREA -->
<table border="0" cellpadding="5" cellspacing="0" width="530">
<tbody>
<tr valign="top">
<td width="40%"><img src="images/model1.gif" alt="" border="0" height="158" width="145">
<div class="boxer">
<p>Please contact us <a href="contactus.php">here</a>.</p></div></td>
<td width="60%">
<div class="content"><span class="heading">:: Who We Are :: </span>
<p><em>Carol Meyer Floor Plans and Design Services</em> is a division of <em>Carol Meyer Interior Design Inc</em>. We have been preparing floor plans for real estate brokers and homeowners since 1996. During this time we have created a library of over 15,000 floor plans for properties in Boston and surrounding areas.</p>
<p>Our small but efficient staff enables us to provide our services on an timely basis.</p>
<p><strong>We are . . . .</strong></p>
<ul>
<li>Carol Meyer, Principal</li>
<li>Angela Casadonte, Manager</li>
<li>Nicole Fenocchi, CAD Operator</li>
<li>Arlene Mentovay, CAD Operator</li></ul></div></td></tr></tbody></table><!-- END CONTENT AREA --></div></td>
<td background="images/box/right.gif" width="12"><img src="images/box/right.gif" alt="" border="0" height="360" width="12"></td></tr>
<tr height="12">
<td background="images/box/bottom.gif" height="12" width="540"><img src="images/box/bottom.gif" alt="" border="0" height="12" width="540"></td>
<td background="images/box/cornerbut.gif" height="12" width="12"><img src="images/box/cornerbut.gif" alt="" border="0" height="12" width="12"></td></tr>
<tr>
<td colspan="2" align="center" valign="top" width="552">					<br>
					<table width="500" border="0" cellspacing="0" cellpadding="0">
						<tr>
							<td align="center" valign="top">
								<div class="footer">
									<p>:: <a href="index.php">Home</a> :: <a href="whoweare.php">Who We Are</a> :: <a href="process.php">Process</a> :: <a href="pricing.php">Pricing</a> :: <a href="samples.php">Samples</a> :: <a href="contactus.php">Contact Us</a> ::</p>
								</div>
							</td>
							<td align="center" valign="middle" width="35"><img src="images/logosm.gif" alt="" width="25" height="25" border="0"></td>
							<td align="left" valign="top">
								<div class="footer">
									Copyright &copy; 2005 Carol Meyer<br>
										All rights reserved<br>
										[ <a href="sitecredits.php">site credits</a> ]</div>
							</td>
						</tr>
					</table><br>
</td>
<td width="248"><br>
</td></tr></tbody></table>
</body>
</html>